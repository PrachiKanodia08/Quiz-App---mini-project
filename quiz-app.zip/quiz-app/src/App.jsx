import React from 'react'
import QuizPage from './components/QuizPage'

const App = () => {
  return (
    <>
      <QuizPage/>
    </>
  )
}

export default App


